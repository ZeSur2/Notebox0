package com.notebox.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.notebox.data.Note
import com.notebox.ui.theme.TerminalComment

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteListScreen(notes: List<Note>, onNoteClick: (Note) -> Unit,
                   onNewNote: () -> Unit, onSettings: () -> Unit) {
    var filter by remember { mutableStateOf("All") }
    val folders = remember(notes) { listOf("All") + notes.map { it.folder }.distinct().sorted() }
    val visible = if (filter == "All") notes else notes.filter { it.folder == filter }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("~/notebox") },
                actions = { IconButton(onClick = onSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings") } },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface))
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewNote) {
                Icon(Icons.Default.Add, contentDescription = "New") }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                folders.forEach { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f },
                        label = { Text(f, style = MaterialTheme.typography.labelSmall) })
                }
            }
            if (visible.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("no notes yet", color = TerminalComment) }
            } else {
                LazyColumn(contentPadding = PaddingValues(12.dp)) {
                    items(visible, key = { it.id }) { note ->
                        NoteCard(note) { onNoteClick(note) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NoteCard(note: Note, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (note.pinned) Text("📌 ", style = MaterialTheme.typography.titleLarge)
                Text(note.title.ifBlank { "(untitled)" },
                    style = MaterialTheme.typography.titleLarge, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(4.dp))
            Text(note.content, style = MaterialTheme.typography.bodyMedium,
                maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (note.imagePath != null) {
                Spacer(Modifier.height(4.dp))
                Text("📎 image attached", style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(6.dp))
            Text("${note.folder}  ·  ${java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(note.updatedAt))}",
                style = MaterialTheme.typography.labelSmall, color = TerminalComment)
        }
    }
}
