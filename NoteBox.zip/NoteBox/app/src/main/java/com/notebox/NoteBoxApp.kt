package com.notebox

import android.app.Application
import com.notebox.sync.BackupWorker

class NoteBoxApp : Application() {
    override fun onCreate() { super.onCreate(); BackupWorker.schedule(this) }
}
