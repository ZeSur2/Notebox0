package com.notebox.sync

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

class BackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        BackupManager.backupNow(applicationContext); return Result.success()
    }
    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<BackupWorker>(1, TimeUnit.DAYS)
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build()).build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("notebox_backup", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
