package com.notebox.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

object ImageStore {
    fun save(context: Context, uri: Uri): String? {
        val dir = File(context.filesDir, "attachments").apply { mkdirs() }
        val file = File(dir, "${UUID.randomUUID()}.jpg")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            }
            file.name
        } catch (e: Exception) { null }
    }
    fun resolve(context: Context, name: String): File =
        File(context.filesDir, "attachments/$name")
}
