package com.notebox.sync

import android.content.Context
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

class WebDavClient(private val baseUrl: String, user: String, pass: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            chain.proceed(chain.request().newBuilder()
                .header("Authorization", Credentials.basic(user, pass)).build())
        }.build()
    private fun trim(url: String) = url.trimEnd('/')

    suspend fun uploadLatest(ctx: Context): Boolean {
        val latest = BackupManager.backupDir(ctx).listFiles()?.maxByOrNull { it.lastModified() }
            ?: BackupManager.backupNow(ctx) ?: return false
        return try {
            val req = Request.Builder().url("${trim(baseUrl)}/notebox-latest.json")
                .put(latest.asRequestBody("application/json".toMediaType())).build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (e: Exception) { false }
    }

    suspend fun downloadLatest(ctx: Context): Boolean = try {
        val req = Request.Builder().url("${trim(baseUrl)}/notebox-latest.json").build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@use false
            val file = File(BackupManager.backupDir(ctx), "downloaded.json")
            resp.body?.byteStream()?.use { inp -> file.outputStream().use { out -> inp.copyTo(out) } }
            true
        }
    } catch (e: Exception) { false }
}
