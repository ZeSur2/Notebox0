package com.notebox.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val TerminalBg = Color(0xFF272822)
val TerminalSurface = Color(0xFF1E1F1C)
val TerminalFg = Color(0xFFF8F8F2)
val TerminalGreen = Color(0xFFA6E22E)
val TerminalCyan = Color(0xFF66D9EF)
val TerminalComment = Color(0xFF75715E)

private val DarkColors = darkColorScheme(
    background = TerminalBg, surface = TerminalSurface,
    onBackground = TerminalFg, onSurface = TerminalFg,
    primary = TerminalGreen, secondary = TerminalCyan)
private val LightColors = lightColorScheme(
    primary = Color(0xFF2E7D32), secondary = Color(0xFF00695C))

private val Mono = FontFamily.Monospace
private val AppTypography = Typography(
    bodyLarge = TextStyle(fontFamily = Mono, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = Mono, fontSize = 13.sp, lineHeight = 19.sp),
    titleLarge = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 20.sp),
    labelSmall = TextStyle(fontFamily = Mono, fontSize = 11.sp, color = TerminalComment))

@Composable
fun NoteBoxTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography, content = content)
}
