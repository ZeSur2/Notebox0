package com.notebox

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.glance.appwidget.updateAll
import com.notebox.widget.NoteBoxWidget
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.notebox.data.Note
import com.notebox.data.NoteDatabase
import com.notebox.ui.NoteEditScreen
import com.notebox.ui.NoteListScreen
import com.notebox.ui.SettingsScreen
import com.notebox.ui.theme.NoteBoxTheme
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object List : Screen()
    data class Edit(val note: Note?) : Screen()
    object Settings : Screen()
}

class NoteViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = NoteDatabase.get(app).noteDao()
    private val appCtx = app
    val notes = dao.observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    fun save(note: Note) = viewModelScope.launch { dao.upsert(note); NoteBoxWidget().updateAll(appCtx) }
    fun delete(note: Note) = viewModelScope.launch { dao.delete(note); NoteBoxWidget().updateAll(appCtx) }
}

class MainActivity : ComponentActivity() {
    private val vm: NoteViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NoteBoxTheme {
                val notes by vm.notes.collectAsStateWithLifecycle()
                var screen by remember { mutableStateOf<Screen>(Screen.List) }
                when (val s = screen) {
                    is Screen.List -> NoteListScreen(
                        notes = notes,
                        onNoteClick = { screen = Screen.Edit(it) },
                        onNewNote = { screen = Screen.Edit(null) },
                        onSettings = { screen = Screen.Settings })
                    is Screen.Edit -> NoteEditScreen(
                        initial = s.note, onSave = { vm.save(it) },
                        onDelete = { vm.delete(it) }, onBack = { screen = Screen.List })
                    is Screen.Settings -> SettingsScreen(onBack = { screen = Screen.List })
                }
            }
        }
    }
}
