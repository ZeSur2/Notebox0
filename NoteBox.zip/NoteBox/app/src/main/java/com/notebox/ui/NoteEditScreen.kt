package com.notebox.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.notebox.data.ImageStore
import com.notebox.data.Note
import com.notebox.ui.theme.TerminalComment

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditScreen(initial: Note?, onSave: (Note) -> Unit,
                   onDelete: (Note) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var content by remember { mutableStateOf(initial?.content ?: "") }
    var folder by remember { mutableStateOf(initial?.folder ?: "Inbox") }
    var imageFile by remember {
        mutableStateOf(initial?.imagePath?.let { ImageStore.resolve(context, it) }) }
    var bgColor by remember { mutableStateOf(initial?.customBgColor) }
    var textColor by remember { mutableStateOf(initial?.customTextColor) }
    var fontScale by remember { mutableStateOf(initial?.widgetFontScale ?: 1.0f) }
    var pinned by remember { mutableStateOf(initial?.pinned ?: false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri: Uri? ->
            uri ?: return@rememberLauncherForActivityResult
            ImageStore.save(context, uri)?.let { imageFile = ImageStore.resolve(context, it) }
        })

    fun build(): Note = (initial ?: Note()).copy(
        title = title.trim(), content = content, folder = folder,
        imagePath = imageFile?.name, customBgColor = bgColor, customTextColor = textColor,
        widgetFontScale = fontScale, pinned = pinned, updatedAt = System.currentTimeMillis())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (initial == null) "new_note" else "edit_note") },
                navigationIcon = {
                    IconButton(onClick = { onSave(build()); onBack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Save") }
                },
                actions = {
                    if (initial != null) IconButton(onClick = { onDelete(initial); onBack() }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete") }
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(Icons.Default.PushPin, contentDescription = "Pin",
                            tint = if (pinned) MaterialTheme.colorScheme.primary else TerminalComment) }
                    TextButton(onClick = { onSave(build()); onBack() }) { Text(":wq") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("title") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(folder, { folder = it }, label = { Text("folder") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(content, { content = it }, label = { Text("content...") },
                modifier = Modifier.fillMaxWidth().height(240.dp),
                textStyle = MaterialTheme.typography.bodyLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(PickVisualMediaRequest(
                    ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("📎 attach image") }
                if (imageFile != null) OutlinedButton(onClick = { imageFile = null }) {
                    Text("remove") }
            }
            imageFile?.let { f -> if (f.exists()) Image(
                painter = rememberAsyncImagePainter(f), contentDescription = null,
                modifier = Modifier.fillMaxWidth().height(180.dp)) }
            HorizontalDivider()
            Text("widget appearance", style = MaterialTheme.typography.titleLarge)
            Text("background color", style = MaterialTheme.typography.labelSmall)
            ColorRow(bgColor) { bgColor = it }
            Text("text color", style = MaterialTheme.typography.labelSmall)
            ColorRow(textColor) { textColor = it }
            Text("font scale: %.2f×".format(fontScale), style = MaterialTheme.typography.labelSmall)
            Slider(value = fontScale, onValueChange = { fontScale = it }, valueRange = 0.7f..1.6f)
            Text("Unset colors fall back to folder default, then global default.",
                style = MaterialTheme.typography.labelSmall, color = TerminalComment)
            Spacer(Modifier.height(24.dp))
        }
    }
}

private val Palette = listOf(null, 0xFF272822, 0xFF1E1F1C, 0xFF0F1115, 0xFF2B213A,
    0xFFA6E22E, 0xFF66D9EF, 0xFFF92672, 0xFFFD971F, 0xFFF8F8F2, 0xFFD4D4D4, 0xFFFFFFFF)

@Composable
private fun ColorRow(selected: Long?, onPick: (Long?) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.padding(vertical = 4.dp)) {
        Palette.forEach { c ->
            Box(Modifier.size(28.dp)
                .background(if (c == null) Color.Transparent else Color(c))
                .border(if (selected == c) 2.dp else 1.dp,
                    if (selected == c) MaterialTheme.colorScheme.primary else TerminalComment)
                .clickable { onPick(c) }, contentAlignment = Alignment.Center) {
                if (c == null) Text("∅", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
