package com.notebox.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.dataStore by preferencesDataStore("notebox_prefs")

object Prefs {
    private val DEFAULT_BG = longPreferencesKey("default_bg")
    private val DEFAULT_TEXT = longPreferencesKey("default_text")

    suspend fun getDefaultBg(ctx: Context): Long =
        ctx.dataStore.data.first()[DEFAULT_BG] ?: 0xFF272822
    suspend fun getDefaultText(ctx: Context): Long =
        ctx.dataStore.data.first()[DEFAULT_TEXT] ?: 0xFFF8F8F2
    suspend fun setDefaultBg(ctx: Context, color: Long) { ctx.dataStore.edit { it[DEFAULT_BG] = color } }
    suspend fun setDefaultText(ctx: Context, color: Long) { ctx.dataStore.edit { it[DEFAULT_TEXT] = color } }

    private fun folderBg(f: String) = longPreferencesKey("folder_bg_$f")
    private fun folderText(f: String) = longPreferencesKey("folder_text_$f")
    suspend fun getFolderBg(ctx: Context, folder: String): Long? =
        ctx.dataStore.data.first()[folderBg(folder)]
    suspend fun getFolderText(ctx: Context, folder: String): Long? =
        ctx.dataStore.data.first()[folderText(folder)]
    suspend fun setFolderColors(ctx: Context, folder: String, bg: Long?, text: Long?) {
        ctx.dataStore.edit {
            if (bg != null) it[folderBg(folder)] = bg else it.remove(folderBg(folder))
            if (text != null) it[folderText(folder)] = text else it.remove(folderText(folder))
        }
    }

    private val WEBDAV_URL = stringPreferencesKey("webdav_url")
    private val WEBDAV_USER = stringPreferencesKey("webdav_user")
    private val WEBDAV_PASS = stringPreferencesKey("webdav_pass")
    data class WebDav(val url: String, val user: String, val pass: String)
    suspend fun getWebDav(ctx: Context): WebDav {
        val p = ctx.dataStore.data.first()
        return WebDav(p[WEBDAV_URL] ?: "", p[WEBDAV_USER] ?: "", p[WEBDAV_PASS] ?: "")
    }
    suspend fun setWebDav(ctx: Context, url: String, user: String, pass: String) {
        ctx.dataStore.edit { it[WEBDAV_URL] = url; it[WEBDAV_USER] = user; it[WEBDAV_PASS] = pass }
    }
}
